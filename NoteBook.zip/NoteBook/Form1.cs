using System.IO;

namespace NoteBook
{
    public partial class Form1 : Form
    {
        private string path = @"C:\testtext.txt";
        private string textValue;


        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            textValue = System.IO.File.ReadAllText(path);
            richTextBox1.Text = textValue;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            System.IO.File.WriteAllText(path, richTextBox1.Text);
        }

    }
}