﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Watch.ucPanel
{
    public partial class ThemePanel : UserControl
    {
        public ThemePanel(Form1 parentForm)
        {
            InitializeComponent();
        }
        private void btnChangeTheme_Click(object sender, EventArgs e)
        {
            // ThemePanel의 버튼 클릭 시 DigitalClockPanel의 BackgroundImage를 변경하는 로직 추가
            Form1 form1 = this.ParentForm as Form1;
            if (form1 != null)
            {
                // DigitalClockPanel의 BackgroundImage를 gradation.jpg로 변경
                form1.DigitalClockPanel.BackgroundImage = Properties.Resources.gradation;
            }
        }
    }
}
