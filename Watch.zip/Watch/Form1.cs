using System;
using System.Windows.Forms;
using System.Net.Http;
using Newtonsoft.Json;

namespace Watch
{
    public partial class Form1 : Form
    {
        ucPanel.AlarmPanel alarmPanel = new ucPanel.AlarmPanel();
        ucPanel.StopwatchPanel stopwatchPanel = new ucPanel.StopwatchPanel();
        ucPanel.CalendarPanel calendarPanel = new ucPanel.CalendarPanel();
        ucPanel.ThemePanel themePanel = new ucPanel.ThemePanel();
        private const string ApiKey = "2f824630adf7b458d556c341f467460b"; // OpenWeatherMap���� �߱޹��� API Ű�� �Է��ϼ���.

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            timer1.Interval = 100; // 1�ʸ��� ������Ʈ
            timer1.Start();
            //LoadWeatherData();
        }
        private async void LoadWeatherData()
        {
            string city = "Seoul"; // ��ȸ�� ���ø��� �Է��ϼ���.
            string country = "KR"; // ���� �ڵ带 �Է��ϼ��� (��: �ѱ��� "KR", �̱��� "US" ��).

            string apiUrl = $"http://api.openweathermap.org/data/2.5/weather?q={city},{country}&appid={ApiKey}&units=metric";

            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    HttpResponseMessage response = await httpClient.GetAsync(apiUrl);
                    string responseData = await response.Content.ReadAsStringAsync();

                    if (response.IsSuccessStatusCode)
                    {
                        WeatherData weatherData = JsonConvert.DeserializeObject<WeatherData>(responseData);

                        // ���� ���� ���
                        string weatherdata = $"{weatherData.Weather[0].Description}";
                        string tempdata = $"{weatherData.Main.Temp}��C";
                        string humiddata = $"{weatherData.Main.Humidity}%";
                        string citydata = $"{weatherData.Name}";
                        string winddata = $"{weatherData.Wind.Speed} m/s";
                        TempLabel.Text = tempdata;
                        Weatherlabel.Text = weatherdata;
                        HumidLabel.Text = humiddata;
                        CityLabel.Text = citydata;
                    }
                    else
                    {
                        TempLabel.Text = "?";
                        Weatherlabel.Text = "?";
                        HumidLabel.Text = "?";
                        CityLabel.Text = "?";
                    }
                }
            }
            catch (Exception ex)
            {
                TempLabel.Text = $"���� �߻�: {ex.Message}";
                Weatherlabel.Text = $"���� �߻�: {ex.Message}";
                HumidLabel.Text = $"���� �߻�: {ex.Message}";
                CityLabel.Text = $"���� �߻�: {ex.Message}";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime currentTime = DateTime.Now;
            TimeLabel.Text = currentTime.ToString("hh:mm:ss tt"); // ���� �ð� ǥ��
            DateLabel.Text = currentTime.ToString("yyyy-MM-dd"); // ���� ��¥ ǥ��
        }

        private void �˶�ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pMain.Controls.Clear();
            pMain.Controls.Add(alarmPanel);
        }

        private void ��ž��ġToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pMain.Controls.Clear();
            pMain.Controls.Add(stopwatchPanel);
        }

        private void Ķ����ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pMain.Controls.Clear();
            pMain.Controls.Add(calendarPanel);
        }

        private void �Ƴ��α׽ð�ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pMain.Controls.Clear();
        }

        private void �׸�ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pMain.Controls.Clear();
            pMain.Controls.Add(themePanel);
        }
    }
    public class WeatherData
    {
        public string Name { get; set; }
        public Weather[] Weather { get; set; }
        public MainInfo Main { get; set; }
        public Wind Wind { get; set; }
    }

    public class Weather
    {
        public string Description { get; set; }
    }

    public class MainInfo
    {
        public double Temp { get; set; }
        public int Humidity { get; set; }
    }

    public class Wind
    {
        public double Speed { get; set; }
    }
}