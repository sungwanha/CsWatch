﻿using System;
using System.Threading;
using static System.Console;

namespace alram_
{
    class TimeObject
    {
        public int year;
        public int month;
        public int day;
        public int hour;
        public int minute;
        public int second;

        public TimeObject(int year, int month, int day, int hour, int minute, int second)
        {
            this.year = year;
            this.month = month;
            this.day = day;
            this.hour = hour;
            this.minute = minute;
            this.second = second;
        }
    }
    class Alarm
    {
        private DateTime alarmTime; // 알람 시간
        private bool isAlarmSet; // 알람 설정 여부
        

        // 년, 월, 일, 시간, 분, 초로 알람 시간을 설정하는 메서드
        public void SetAlarmFromDateTime(int year, int month, int day, int hour, int minute, int second)
        {
            // 입력된 년, 월, 일, 시간, 분, 초로 알람 시간을 설정합니다.
            alarmTime = new DateTime(year, month, day, hour, minute, second);

            // 알람이 설정되었음을 표시합니다.
            isAlarmSet = true;
        }
        // 사용자로부터 직접 알람 시간을 설정하는 메서드

        TimeObject[] alram_list;
        int alram_count = 0;

        public Alarm()
        {
            alram_list = new TimeObject[10];
            alram_count = 0;

        }
        public void SetAlarmManually()
        {
            WriteLine("=======================");
            WriteLine("알람 시간을 설정하세요.");
            WriteLine("=======================");

            Write("년: ");
            int year = int.Parse(ReadLine());
            Write("월: ");
            int month = int.Parse(ReadLine());
            Write("일: ");
            int day = int.Parse(ReadLine());
            Write("시: ");
            int hour = int.Parse(ReadLine());
            Write("분: ");
            int minute = int.Parse(ReadLine());
            Write("초: ");
            int second = int.Parse(ReadLine());

            SetAlarmFromDateTime(year, month, day, hour, minute, second);

            WriteLine("{0}년 {1}월 {2}일 {3}시 {4}분 {5}초 알람이 울릴 예정입니다.", year, month, day, hour, minute, second);
        }

        public Alarm()
        {
            isAlarmSet = false;
        }

        public void SetAlarm(DateTime time)
        {
            alarmTime = time;
            isAlarmSet = true;
        }

        public void Start()
        {
            if (isAlarmSet)
            {
                TimeSpan timeToWait = alarmTime - DateTime.Now;
                if (timeToWait.TotalMilliseconds > 0)
                {
                    Thread.Sleep(timeToWait);
                }
                WriteLine("알람이 울립니다!");
            }
            else
            {
                WriteLine("알람이 설정되지 않았습니다.");
            }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Alarm alarm = new Alarm();

            // 사용자로부터 알람 시간을 직접 설정
            alarm.SetAlarmManually();

            // 알람 시작
            alarm.Start();

            WriteLine("프로그램이 종료됩니다.");
        }
    }
}

