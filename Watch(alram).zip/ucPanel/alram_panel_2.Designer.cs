﻿namespace Watch.ucPanel
{
    partial class alram_panel_2
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(103, 224);
            button1.Name = "button1";
            button1.Size = new Size(84, 41);
            button1.TabIndex = 0;
            button1.Text = "알람 등록 버튼(동그라미)";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(22, 18);
            button2.Name = "button2";
            button2.Size = new Size(255, 44);
            button2.TabIndex = 1;
            button2.Text = "현재 시간 보여주기";
            button2.UseVisualStyleBackColor = true;
            // 
            // alram_panel_2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "alram_panel_2";
            Size = new Size(297, 294);
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
    }
}
